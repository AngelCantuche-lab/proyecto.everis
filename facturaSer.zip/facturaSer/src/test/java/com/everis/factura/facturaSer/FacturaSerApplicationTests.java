package com.everis.factura.facturaSer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturaSerApplicationTests {

	@Test
	void contextLoads() {
	}

}
