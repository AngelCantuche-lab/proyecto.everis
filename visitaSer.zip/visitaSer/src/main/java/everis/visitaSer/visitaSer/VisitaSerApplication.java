package everis.visitaSer.visitaSer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VisitaSerApplication {

	public static void main(String[] args) {
		SpringApplication.run(VisitaSerApplication.class, args);
	}

}
